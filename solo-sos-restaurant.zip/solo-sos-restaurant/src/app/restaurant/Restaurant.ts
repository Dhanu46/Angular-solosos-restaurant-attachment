export interface Restaurant{
    gstin:string,
    restaurantName:string,
    phoneNumber:string,
    emailId : string,
    imageFile : any,
    alternatePhoneNumber:string,
    fssai : string,
    contactPerson: string,
    restaurantImage : any,
    address : string,
    linkedTo : Array<string>,
    contactPersonPhoneNumber : string,
    contactPersonRole : string
}