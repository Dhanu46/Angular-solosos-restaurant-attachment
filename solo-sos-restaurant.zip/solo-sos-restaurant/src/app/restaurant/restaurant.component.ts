import { HttpClient } from '@angular/common/http';
import { RestaurantService } from './../restaurant.service';
import { Component, OnInit } from '@angular/core';
import { Restaurant } from './Restaurant';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-restaurant',
  templateUrl: './restaurant.component.html',
  styleUrls: ['./restaurant.component.css']
})
export class RestaurantComponent{

  constructor(private service:RestaurantService,private http:HttpClient) { }

  LinkedWith = ["swiggy","zomato","donzo","none"];
  url = "http://localhost:8081/addRestaurant";
  restaurant:Restaurant={
    gstin:"",
    restaurantName:"",
    phoneNumber:"",
    emailId : "",
    restaurantImage: File,
    alternatePhoneNumber:"",
    imageFile : File,
    fssai : "",
    contactPerson : "",
    address : "",
    contactPersonPhoneNumber : "",
    contactPersonRole : "",
    linkedTo : ["","","",""]
  }

  
  public addRestaurant(){
   const fd = new FormData();
   fd.append('gstin',this.restaurant.gstin);
   fd.append('restaurantName',this.restaurant.restaurantName);
   fd.append('phoneNumber',this.restaurant.phoneNumber);
   fd.append('emailId',this.restaurant.emailId);
   fd.append('restaurantImage',this.restaurant.restaurantImage);
   fd.append('alternatePhoneNumber',this.restaurant.alternatePhoneNumber);
   fd.append('imageFile',this.restaurant.imageFile);
   fd.append('fssai',this.restaurant.fssai);
   fd.append('contactPerson',this.restaurant.contactPerson);
   fd.append('address',this.restaurant.address);
   fd.append('contactPersonPhoneNumber',this.restaurant.contactPersonPhoneNumber);
   fd.append('contactPersonRole',this.restaurant.contactPersonRole);
   fd.append('linkedTo',this.restaurant.linkedTo.toString());
   
   this.http.post(this.url,fd)
   .subscribe((response)=>{
      console.log(response);
    }
    ,(err)=>{
      console.log(err);
    })
  }
  public logout(){
  this.service.logout();
  }
  public onFileSelect(event){
    if(event.target.files.length>0){
      const file = event.target.files[0];
      this.restaurant.imageFile = file;
    }
  }

  public onFileSelect1(event){
    if(event.target.files.length>0){
      const file = event.target.files[0];
      this.restaurant.restaurantImage = file;
    }
  }

}
