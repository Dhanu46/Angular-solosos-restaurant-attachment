import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Restaurant } from './restaurant/Restaurant';

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {
  
  constructor(private http:HttpClient,private route:Router) { }
  
   
  logout(){
    this.route.navigateByUrl("login");
  }

}
